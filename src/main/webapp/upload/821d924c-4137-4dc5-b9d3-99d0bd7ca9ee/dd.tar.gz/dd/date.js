
var menuData = [
           {id:1000,pid:-1,name:"角色管理",url:"",children:[
                {id:1001,pid:1000,name:"分配权限",url:""},
                {id:1001,pid:1000,name:"创建角色",url:""},
                {id:1001,pid:1000,name:"分配人员",url:""},
                {id:1001,pid:1000,name:"撤销权限",url:""}
            ]},
            {id:2000,pid:-1,name:"资源管理",url:"",children:[
                {id:1001,pid:2000,name:"创建资源",url:"addModule.html"},
                {id:1001,pid:2000,name:"分配资源",url:""}
            ]},
            {id:3000,pid:-1,name:"用户管理",url:"",children:[
                {id:2001,pid:3000,name:"修改用户",url:""},
                {id:2002,pid:3000,name:"创建用户",url:""},
                {id:2002,pid:3000,name:"分配角色",url:""}
            ]},
              {id:4000,pid:-1,name:"用户管理",url:""}
        ];
        
